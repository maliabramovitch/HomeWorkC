//
// Malka Abramovitch 314723586
// Dor Shukrun 203841697
//

#ifndef INC_4_TEST_HIST_H
#define INC_4_TEST_HIST_H

void hist_test();

#endif //INC_4_TEST_HIST_H
